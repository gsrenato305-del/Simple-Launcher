package com.simpletv.launcher;

import android.app.Activity;
import android.app.RoleManager;
import android.content.SharedPreferences;
import android.os.Build;
import android.app.SearchManager;
import android.net.Uri;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TimeZone;

public class MainActivity extends Activity {
    private WebView web;
    private volatile String cache;

    private final BroadcastReceiver pkgRx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            cache = null;
            js("window.refreshApps&&window.refreshApps()");
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        web.requestFocus();
        web.postDelayed(this::askDefaultHome, 1500);
    }

    private boolean isDefaultHome() {
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && getPackageName().equals(ri.activityInfo.packageName);
    }

    // Pede ao sistema para virar o launcher padrão (até 3 vezes enquanto não for)
    private void askDefaultHome() {
        SharedPreferences sp = getSharedPreferences("sv", MODE_PRIVATE);
        int n = sp.getInt("ask", 0);
        if (n >= 3 || isDefaultHome()) return;
        sp.edit().putInt("ask", n + 1).apply();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    if (!rm.isRoleHeld(RoleManager.ROLE_HOME))
                        startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 77);
                    return;
                }
            }
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            js("toast('Não foi possível definir como padrão automaticamente')");
        }
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f.addDataScheme("package");
        registerReceiver(pkgRx, f);
    }

    @Override protected void onStop() {
        super.onStop();
        try { unregisterReceiver(pkgRx); } catch (Exception e) { }
    }

    @Override protected void onResume() {
        super.onResume();
        js("window.refreshApps&&window.refreshApps()");
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i.hasCategory(Intent.CATEGORY_HOME)) js("window.onBack&&window.onBack()");
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    // Launcher nunca fecha com Voltar: repassa ao HTML
    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (e.getAction() == KeyEvent.ACTION_UP) js("window.onBack&&window.onBack()");
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    private void js(String code) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private String enc(Drawable d, int w, int h, boolean png) {
        Bitmap bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        if (!png) c.drawColor(0xFF1A1A1E);
        d.setBounds(0, 0, w, h);
        d.draw(c);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        bm.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 85, o);
        bm.recycle();
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP);
    }

    private String buildApps() {
        PackageManager pm = getPackageManager();
        Map<String, ResolveInfo> m = new LinkedHashMap<>();
        for (String cat : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String p = ri.activityInfo.packageName;
                if (!p.equals(getPackageName()) && !m.containsKey(p)) m.put(p, ri);
            }
        }
        JSONArray arr = new JSONArray();
        for (ResolveInfo ri : m.values()) {
            try {
                String n = ri.loadLabel(pm).toString();
                JSONObject o = new JSONObject();
                o.put("n", n);
                o.put("p", ri.activityInfo.packageName);
                o.put("t", n.length() > 1 ? n.substring(0, 2) : n);
                o.put("i", enc(ri.loadIcon(pm), 128, 128, true));
                Drawable bn = ri.activityInfo.loadBanner(pm);
                if (bn != null) o.put("b", enc(bn, 320, 180, false));
                arr.put(o);
            } catch (Exception e) { }
        }
        return arr.toString();
    }

    private void start(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    class Bridge {
        @JavascriptInterface public String apps() {
            String c = cache;
            if (c == null) { c = buildApps(); cache = c; }
            return c;
        }

        @JavascriptInterface public void launch(String pkg) {
            runOnUiThread(() -> {
                try {
                    PackageManager pm = getPackageManager();
                    Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
                    if (i == null) i = pm.getLaunchIntentForPackage(pkg);
                    if (i != null) start(i);
                } catch (Exception e) { }
            });
        }

        @JavascriptInterface public void search() {
            runOnUiThread(() -> {
                for (String a : new String[]{Intent.ACTION_VOICE_COMMAND, Intent.ACTION_ASSIST, Intent.ACTION_WEB_SEARCH}) {
                    try { start(new Intent(a)); return; } catch (Exception e) { }
                }
                js("toast('Busca indisponível neste aparelho')");
            });
        }

        @JavascriptInterface public void watch(String pkg, String title) {
            runOnUiThread(() -> {
                String q = Uri.encode(title), p = pkg.toLowerCase();
                String url = p.contains("netflix") ? "nflx://www.netflix.com/search?q=" + q
                        : p.contains("disney") ? "https://www.disneyplus.com/search?q=" + q
                        : p.contains("amazon") ? "https://app.primevideo.com/search?phrase=" + q
                        : p.contains("globo") ? "https://globoplay.globo.com/busca/?q=" + q
                        : (p.contains("wbd") || p.contains("hbo")) ? "https://play.max.com/search?q=" + q
                        : p.contains("apple") ? "https://tv.apple.com/search?term=" + q
                        : p.contains("paramount") ? "https://www.paramountplus.com/search/?q=" + q : null;
                if (url != null) {
                    try { start(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg)); return; } catch (Exception e) { }
                }
                try { start(new Intent(Intent.ACTION_SEARCH).setPackage(pkg).putExtra(SearchManager.QUERY, title)); return; } catch (Exception e) { }
                try {
                    PackageManager pm = getPackageManager();
                    Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
                    if (i == null) i = pm.getLaunchIntentForPackage(pkg);
                    if (i != null) { start(i); js("toast('Procure por ' + " + JSONObject.quote(title) + ")"); }
                } catch (Exception e) { }
            });
        }

        // Hora e fuso do sistema da TV (a WebView às vezes erra o fuso)
        @JavascriptInterface public void setDefault() {
            runOnUiThread(() -> {
                getSharedPreferences("sv", MODE_PRIVATE).edit().putInt("ask", 0).apply();
                askDefaultHome();
            });
        }

        @JavascriptInterface public int tzo() {
            return TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000;
        }

        @JavascriptInterface public boolean h24() {
            return android.text.format.DateFormat.is24HourFormat(MainActivity.this);
        }

        @JavascriptInterface public void settings() {
            runOnUiThread(() -> {
                try { start(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception e) { }
            });
        }
    }
}
